# Readme

This is a prototype version 

# setup command
pip install ./text2image

# run command
python main.py

# To modify input text
## you need to modify "input text" in "process.py"

# To see the selected pictures 
## goto data/save/ directory


lastupdated 2023 Aug 28
